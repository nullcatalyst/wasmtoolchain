#pragma once

#ifndef __cplusplus

#define true 1
#define false 0
#define bool _Bool

#endif
