#pragma once

#include <limits.h>
#include <stddef.h>

#define __NEED_sized_int_t
#include <bits/alltypes.h>
