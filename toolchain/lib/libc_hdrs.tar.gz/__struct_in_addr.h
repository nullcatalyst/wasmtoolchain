#ifndef __wasilibc___struct_in_addr_h
#define __wasilibc___struct_in_addr_h

#include <__typedef_in_addr_t.h>

struct in_addr {
    in_addr_t s_addr;
};

#endif
