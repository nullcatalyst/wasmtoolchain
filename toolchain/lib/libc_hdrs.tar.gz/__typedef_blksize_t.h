#ifndef __wasilibc___typedef_blksize_t_h
#define __wasilibc___typedef_blksize_t_h

typedef long blksize_t;

#endif
